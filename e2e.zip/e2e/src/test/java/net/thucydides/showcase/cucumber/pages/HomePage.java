package net.thucydides.showcase.cucumber.pages;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl("file:///media/bogdan/Data/glovo/ui-test-assessment/employees.html")
public class HomePage extends PageObject {


    private final static String VIEW_SELECT_DATA = "//button[@id='btn']";
    
    public void selectEmployee(String keyword) {
    }

    public void clickOnViewSelectedData(){
        $(VIEW_SELECT_DATA).click();
    }

    public String getDisplayedResult(){
        return "";
    }

}

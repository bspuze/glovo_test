package net.thucydides.showcase.cucumber.steps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import net.thucydides.showcase.cucumber.pages.HomePage;
import net.thucydides.showcase.cucumber.steps.serenity.EmployeesSteps;
import org.junit.Assert;

public class EmployeesScenarioSteps {

    @Steps
    EmployeesSteps employeesSteps;

    HomePage homePage;

    @Given("the user is visiting the homepage")
    public void theUserIsVisitingTheHomepage(String webPage) {
        employeesSteps.opens_home_page();

    }

    @When("he tries to view the location for '(.*)'")
    public void heTriesToViewTheLocationFor(String employee) {
        employeesSteps.display_location_for(employee);
    }

    @Then("he will be able to see '(.*)'")
    public void heWillBeAbleToSee(String expected_result) {
        String result = employeesSteps.get_displayed_result();
        Assert.assertEquals("get_displayed_result",expected_result,result);
    }
}

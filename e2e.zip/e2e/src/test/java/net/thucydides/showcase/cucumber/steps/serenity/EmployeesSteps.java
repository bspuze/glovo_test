package net.thucydides.showcase.cucumber.steps.serenity;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import net.thucydides.showcase.cucumber.pages.HomePage;

public class EmployeesSteps extends ScenarioSteps {

    HomePage homePage;

    @Step
    public void opens_home_page() {
        homePage.open();
    }

    @Step
    public void display_location_for(String employee) {
        homePage.selectEmployee(employee);
        homePage.clickOnViewSelectedData();
    }

    @Step
    public String get_displayed_result(){
        return homePage.getDisplayedResult();
    }
}
